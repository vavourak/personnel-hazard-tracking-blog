import json
import os
import datetime
import boto3
import random
import time


# Variables
TRACKER_NAME = 'Device_Tracker'
TIME_DB      = 'Device_Time_DB'
TIME_TABLE   = 'Positions'


def lambda_handler(event, context):

    # Check to see if API call has a query string for "duration", which is how long in the past to query position trails.  If missing, default to 10 minutes
    try:
        history_duration = int(event['queryStringParameters']['duration'])
    except KeyError:
        history_duration = 600  # in seconds
    
    # Build Timestream query
    query_string = 'SELECT DeviceID, time, measure_name, measure_value::double, measure_value::bigint FROM "{}"."{}" WHERE time BETWEEN ago({}s) AND now() ORDER BY time DESC'.format(TIME_DB, TIME_TABLE, history_duration)
    print('query={}'.format(query_string))
    
    # Reset dictionary (gets cached if Lambda called often, causing response to grow out of control)
    device_data = {}
    
    client_timestream = boto3.client('timestream-query')
    response = client_timestream.query(QueryString=query_string)
    
    # Process TimeStream response
    # Data stored in TimeStream:
    # 0. timestamp
    # 1. value name
    # 2. latitude/longitude (float)
    # 3. gas readings (int)
    for i in range(0, len(response['Rows'])):
        #print(response['Rows'][i]['Data'][1]['ScalarValue'])
        device_id = response['Rows'][i]['Data'][0]['ScalarValue']
        timestamp = response['Rows'][i]['Data'][1]['ScalarValue']
        name      = response['Rows'][i]['Data'][2]['ScalarValue']
        
        if device_data.get(device_id) is None:
            device_data.update({device_id: {}})
        if device_data[device_id].get(timestamp) is None:
            device_data[device_id].update({timestamp: {}})
        if name == 'gas_reading':
            gas_reading = response['Rows'][i]['Data'][4]['ScalarValue']
            device_data[device_id][timestamp].update({'gas_reading':gas_reading})
        elif name == 'latitude':
            latitude = response['Rows'][i]['Data'][3]['ScalarValue']
            device_data[device_id][timestamp].update({'latitude':latitude})
        elif name == 'longitude':
            longitude = response['Rows'][i]['Data'][3]['ScalarValue']
            device_data[device_id][timestamp].update({'longitude':longitude})

    # Build GeoJSON payload to return
    payload = {
        "type": "FeatureCollection",
        "features": [
        ]
    }

    # Convert data to GeoJSON format
    for device_id in device_data:
        for timestamp in device_data[device_id]:
            try: 
                # Check to see if variables are present, catch the KeyError if not
                _ = device_data[device_id][timestamp]['longitude']
                _ = device_data[device_id][timestamp]['latitude']
                
                # Generate GeoJSON feature
                feature = {
                    "type": "Feature",
                    "properties": {
                        'DeviceId': device_id,
                        'gas_reading': int(device_data[device_id][timestamp]['gas_reading']),
                        'timestamp': timestamp
                    },
                    "geometry": {
                        "type": "Point",
                        "coordinates": [
                            float(device_data[device_id][timestamp]['longitude']),
                            float(device_data[device_id][timestamp]['latitude'])
                        ]
                    }
                }
                
                # Append data to payload
                payload['features'].append(feature)
                
            except KeyError as e:
                pass
    
    return {
        'statusCode': 200,
        'body': json.dumps(payload)
    }
