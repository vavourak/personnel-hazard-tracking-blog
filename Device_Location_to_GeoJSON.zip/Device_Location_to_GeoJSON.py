import json
import os
import boto3


# Variables
TRACKER_NAME = 'Device_Tracker'


def lambda_handler(event, context):
    
    # Get positions
    client_loc = boto3.client('location')
    response = client_loc.list_device_positions(TrackerName=TRACKER_NAME)

    # Build GeoJSON response payload
    payload = {
        "type": "FeatureCollection",
        "features": []
    }

    # Iterate through responses (not paginated)
    for entry in response['Entries']:

        # Check to see if tracker has missing position
        try:
            _ = entry['Position'][0]
            _ = entry['Position'][1]
        except KeyError:
            continue

        payload['features'].append({
            "type": "Feature",
            "properties": {'DeviceId': entry['DeviceId']},
            "geometry": {
                "type": "Point",
                "coordinates": [
                    entry['Position'][0],
                    entry['Position'][1]
                ]
            }
        })

    return {
        'statusCode': 200,
        'body': json.dumps(payload)
    }
