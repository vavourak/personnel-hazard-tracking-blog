from datetime import datetime
import json
import os
from decimal import Decimal
import boto3


# Variables
TRACKER_NAME    = 'Device_Tracker'
TS_DB_NAME      = 'Device_Time_DB'
TS_TABLE_NAME   = 'Positions'


def lambda_handler(event, context):

    # Clients
    client_loc = boto3.client('location')
    client_tsw = boto3.client('timestream-write')
    
    # Creating needed variables
    records_ts = []
    records_loc = []
    dimensions = []
    device_gas_reading = []
    device_latitude = []
    device_longitude = []

    # Process messages from SQS
    for record in event['Records']:
        message = json.loads(record['body'])
        
        # ETL data for Location Services
        records_loc.append({
            "DeviceId": message['device_id'],
            "SampleTime": datetime.fromtimestamp(message['time_seconds']).isoformat(),
            "Position": [
                message['longitude'],
                message['latitude']
            ]
        })
        
        # ETL data for Timestream
        dimensions = [{
            'Name'              : 'DeviceID', 
            'Value'             : message['device_id'],
            'DimensionValueType': 'VARCHAR'
            }]

        device_gas_reading = {
            'Dimensions'      : dimensions,
            'MeasureName'     : 'gas_reading',
            'MeasureValue'    : str(message['gas_reading']),
            'MeasureValueType': 'BIGINT',
            'Time'            : str(message['time_seconds']),
            'TimeUnit'        : 'SECONDS'
        }

        device_latitude = {
            'Dimensions'      : dimensions,
            'MeasureName'     : 'latitude',
            'MeasureValue'    : str(message['latitude']),
            'MeasureValueType': 'DOUBLE',
            'Time'            : str(message['time_seconds']),
            'TimeUnit'        : 'SECONDS'
        }

        device_longitude = {
            'Dimensions'      : dimensions,
            'MeasureName'     : 'longitude',
            'MeasureValue'    : str(message['longitude']),
            'MeasureValueType': 'DOUBLE',
            'Time'            : str(message['time_seconds']),
            'TimeUnit'        : 'SECONDS'
        }
        
        records_ts.append(device_gas_reading)
        records_ts.append(device_latitude)
        records_ts.append(device_longitude)
        
    # Batch update Location and Timestream services
    try:
        response = client_loc.batch_update_device_position(TrackerName=TRACKER_NAME, Updates=records_loc)
    except Exception as e:
        print('Error encountered while trying to send messages to Location Service: {}'.format(e))
    try:
        response = client_tsw.write_records(DatabaseName=TS_DB_NAME, TableName=TS_TABLE_NAME, Records=records_ts, CommonAttributes={})
    except Exception as e:
        print('Error encountered while trying to send messages to TimeStream: {}'.format(e))
    
    return {
        "statusCode": 200,
        "body": json.dumps(response)
    }