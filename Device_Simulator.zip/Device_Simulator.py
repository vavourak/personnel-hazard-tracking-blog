from datetime import datetime
import json
import os
import time
import random
import math
import boto3

# Variables
MQTT_TOPIC      = 'Device_Simulator/telemetry'
NUM_SIMS        = 8             # Number of simulated devices
DEVICE_PREFIX   = 'Sim_Device_' # Device name prefix
LAT_MAX         = 29.7220       # Max northing of bounding box
LAT_MIN         = 29.7160       # Min northing
LONG_MAX        = -95.2285      # Max easting
LONG_MIN        = -95.2344      # Min easting
GAS_MIN         = 200           # Min gas sensor reading
GAS_MAX         = 1000          # Max gas sensor reading (sensor maxes out)
GAS_GRADIENT    = 1000000       # Gas disipation gradient with distance
LOOP_TIME       = 555           # How long to run Lambda before restarting.  Set to same time as EventBridge for no overlap (in seconds)
UPDATE_FREQ     = 10            # Time between device updates (seconds)
SPEED           = 0.0001        # Device movement speed per update (in decimal degrees, 0.0001 DDEG = 11.1 m/s)

# Simulated gas leaks
GAS_SPIKE_1_LAT  =  29.71737
GAS_SPIKE_1_LONG = -95.23291
GAS_SPIKE_1      = 1200
GAS_SPIKE_2_LAT  =  29.72107
GAS_SPIKE_2_LONG = -95.23334
GAS_SPIKE_2      = 800

# Initial device setup
device_pos = []
device_dir = []
device_gas = []


for device_num in range(NUM_SIMS):
    device_pos.append({
        "DeviceId": DEVICE_PREFIX + str(device_num),
        "SampleTime": datetime.fromtimestamp(int(time.time())).isoformat(),
        "Position": [
            # Pick random position within bounding box
            random.uniform(LONG_MIN, LONG_MAX),
            random.uniform(LAT_MIN, LAT_MAX)
        ]
    })
    
    # Pick random direction to start moving
    dir = random.randint(0, 359)
    device_dir.append([math.cos(math.radians(dir)), math.sin(math.radians(dir))])
    device_gas.append(200)


def lambda_handler(event, context):
    client_iot = boto3.client('iot-data')

    start_time = time.time()
    
    while True:
        current_time = time.time()
        records = []
        
        # Update positions
        for device_num in range(NUM_SIMS):
            curr_long = device_pos[device_num]['Position'][0]
            curr_lat  = device_pos[device_num]['Position'][1]
            
            # Change direction if outside boarders (bounce off walls)
            if curr_long <= LONG_MIN or curr_long >= LONG_MAX:
                device_dir[device_num] = [-device_dir[device_num][0], device_dir[device_num][1]]
            if curr_lat <= LAT_MIN or curr_lat >= LAT_MAX:
                device_dir[device_num] = [device_dir[device_num][0], -device_dir[device_num][1]]
            
            next_long = device_dir[device_num][0] * SPEED + curr_long
            next_lat  = device_dir[device_num][1] * SPEED + curr_lat
            
            device_pos[device_num]['Position'][0] = next_long
            device_pos[device_num]['Position'][1] = next_lat
        

            # Determine gas readings
            distance_1 = math.hypot(abs(GAS_SPIKE_1_LAT - next_lat), abs(GAS_SPIKE_1_LONG - next_long))
            distance_2 = math.hypot(abs(GAS_SPIKE_2_LAT - next_lat), abs(GAS_SPIKE_2_LONG - next_long))
            gas_reading_1 = min(max(GAS_SPIKE_1 - (GAS_GRADIENT * distance_1), 0), 1000)
            gas_reading_2 = min(max(GAS_SPIKE_2 - (GAS_GRADIENT * distance_2), 0), 1000)
            gas_reading = int(GAS_MIN + gas_reading_1 + gas_reading_2)
            
            message = {
                "device_id": device_pos[device_num]["DeviceId"],
                "source": "Simulator",
                "time_local": datetime.utcnow().timestamp(),
                "datetime_local": str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                "time_seconds": int(time.time()),
                "time_nanos": int((time.time() % 1) * 1E9),
                "gas_reading": gas_reading,
                "latitude": next_lat,
                "longitude": next_long,
            }

            response = client_iot.publish(topic=MQTT_TOPIC, qos=1, payload=json.dumps(message))
            time.sleep(UPDATE_FREQ / 100.0)  # Small wait between sending MQTT messages, as to not flood broker

        time.sleep(UPDATE_FREQ)
        
        # End loop if max time reached
        if LOOP_TIME < (current_time - start_time):
            print('LOOP_TIME {}, current_time {}, start_time {}, delta {}'.format(LOOP_TIME, current_time, start_time, (current_time - start_time)))
            break
        
    return {
        "statusCode": 200,
        "body": "Done"
    }